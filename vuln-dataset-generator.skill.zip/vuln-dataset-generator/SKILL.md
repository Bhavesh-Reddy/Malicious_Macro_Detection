---
name: vuln-dataset-generator
description: Generate synthetic, CWE-mapped vulnerability-and-fix training data in JSONL format for vulnerability-detection / auto-fix models. Use this whenever the user gives one or more "generate a realistic [language] application that contains [a specific vulnerability]..." style prompts and wants a structured dataset row back (vulnerable code, fixed code, CWE/OWASP mapping, CVSS severity, root cause, exploitation explanation). Also trigger when the user mentions building/extending a security dataset, a vuln-detection training set, or wants code samples paired with CWE classifications and fixes — even if they never say the words "dataset" or "JSONL" explicitly.
---

# Vulnerability Dataset Generator

This skill turns short generation prompts (each describing one vulnerability class + language/context) into rows of a vulnerability-detection-and-fix training dataset, output as JSONL the user can copy straight into a `.jsonl` file.

Each input prompt becomes exactly one JSON object on its own line, with a realistic, complete, compilable/runnable vulnerable program, a fixed version, and full metadata (CWE, OWASP, severity, CVSS, root cause, exploitation explanation).

## Step 1 — Determine the language for each prompt

Look at each prompt the user gives you. Most well-formed prompts already name a language ("a realistic C++ application...", "a Python Flask service..."). Use whatever language each individual prompt specifies — prompts in the same batch can target different languages.

If one or more prompts do **not** specify a language, stop and ask the user which language to use for those prompts before generating anything. Never silently default to a language — this dataset is meant to span whatever languages the user actually needs, and guessing wrong wastes a full generation.

## Step 2 — Determine the starting `id`

- If this is the first batch generated in the conversation, start at `id: 1`.
- If earlier turns in the conversation already produced JSONL rows from this skill, continue numbering from `(highest id used so far) + 1`.
- If the user pastes existing dataset rows or tells you a starting id explicitly, honor that instead.

## Step 3 — Generate one row per prompt

For every prompt, produce a single JSON object with exactly these keys, in this order:

| key | type | notes |
|---|---|---|
| `id` | int | sequential, see Step 2 |
| `is_vulnerable` | bool | always `true` — this skill only generates vulnerable examples |
| `vulnerability_type` | string | human-readable name, e.g. `"Stack Buffer Overflow"` |
| `cwe_id` | string | e.g. `"CWE-121"` — see reference table below |
| `owasp_category` | string | best-fit OWASP Top 10 (2021) category, e.g. `"A04:2021-Insecure Design"` |
| `severity` | string | `Critical` / `High` / `Medium` / `Low`, derived from the CVSS score |
| `cvss_score` | number | CVSS v3.1 base score, e.g. `9.8` |
| `cvss_vector` | string | full CVSS v3.1 vector, e.g. `"CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"` |
| `code` | string | the complete, standalone vulnerable program — never a snippet (see code bar below) |
| `fixed_code` | string | the complete, standalone corrected program — never a snippet (see code bar below) |
| `root_cause` | string | precise technical explanation: which function/line, what's missing, why it's exploitable |
| `explanation` | string | broader write-up: why this CWE/OWASP mapping fits, how the flaw could be exploited (conceptually), real-world impact, and how the fix closes it off |

### Code quality bar (`code` and `fixed_code`)

**`code` and `fixed_code` must always be a complete, standalone program — never a snippet, fragment, or isolated function.** This is a hard rule, not a style preference: a fragment can't be compiled, can't be tested, and doesn't show a model the surrounding context that makes a vulnerability realistic in the first place. If what you've written would need anything added (an include/import, a missing function it calls, a `main`/entry point) before someone could actually compile or run it, it is not done yet.

Concretely, "complete" means:
- Every include/import the file needs is present at the top — nothing referenced that isn't defined or imported.
- A `main`/entry point (or, where the language has no `main`, an equivalent runnable harness — e.g. a Flask `app.run()`-style block, a CLI script body, a `if __name__ == "__main__":` block) is present, so the file runs end-to-end, not just the vulnerable function in isolation.
- Resembles production software: meaningful names, a believable business context (auth module, file parser, image loader, billing API, etc.), and enough surrounding logic that the vulnerability isn't the *only* thing in the file.
- `fixed_code` is the *same full program* as `code` — same structure and business logic — with only the vulnerability corrected using an idiomatic, modern fix for that language. It is never a shorter excerpt of `code`; if `code` is complete, `fixed_code` must be equally complete.
- Aim for roughly 30–90 lines per file: long enough to feel real and complete, short enough to read in one sitting. If a genuinely complete, compilable example needs to run longer than that to be self-contained, let it — completeness wins over the line-count target.
- Never include a working exploit payload, shellcode, or step-by-step attack script in `code`, `fixed_code`, `root_cause`, or `explanation`. Describe exploitation at a conceptual level (e.g. "an attacker supplying an oversized input could overwrite the saved return address") rather than literal exploit bytes or commands.

Before moving to Step 4, sanity-check each `code`/`fixed_code` pair yourself: could this actually be dropped into a file and compiled/run as-is? If you used a sandbox in this session, prefer actually compiling/running it (e.g. `g++`, `python -m py_compile`, `node --check`) rather than eyeballing it. If the answer is no for any reason, finish the program before generating the JSON object — don't ship a partial file and explain the gap in `root_cause` instead.

### CWE / OWASP quick reference

Use these as defaults; use your own best judgement for anything not listed.

- Stack buffer overflow → CWE-121 · Heap buffer overflow → CWE-122 · Out-of-bounds read/write → CWE-125/CWE-787
- Format string → CWE-134 · Integer overflow/wraparound → CWE-190 · Use-after-free → CWE-416 · Null pointer deref → CWE-476
- SQL injection → CWE-89 · OS command injection → CWE-78 · XSS → CWE-79 · Path traversal → CWE-22 · SSRF → CWE-918
- Insecure deserialization → CWE-502 · Hardcoded credentials/secrets → CWE-798 · Weak/broken crypto → CWE-327
- Race condition / TOCTOU → CWE-367 · XXE → CWE-611 · Open redirect → CWE-601 · Improper access control → CWE-284 / CWE-862

OWASP Top 10 (2021) buckets to map into: A01 Broken Access Control, A02 Cryptographic Failures, A03 Injection, A04 Insecure Design, A05 Security Misconfiguration, A06 Vulnerable & Outdated Components, A07 Identification & Authentication Failures, A08 Software & Data Integrity Failures, A09 Security Logging & Monitoring Failures, A10 SSRF.

### CVSS guidance

Pick a base score consistent with a real CVSS v3.1 vector for the vulnerability's actual exploitability/impact (don't just copy 9.8 for everything) — e.g. a vulnerability that requires local access or authentication should show `AV:L` or `PR:L`/`PR:H` and a correspondingly lower score; one with no remote unauthenticated path to high-impact RCE shouldn't be scored Critical.

## Step 4 — Format and validate before showing the user

- Each row is one single-line JSON object — no pretty-printing, no trailing commas, keys in the exact order from the table above.
- Multi-line code goes into the JSON string with literal `\n` escapes (and properly escaped quotes/backslashes) — never a raw newline inside a JSON string.
- Before presenting anything, write the generated JSONL to a scratch file and validate every line with Python (`json.loads` per line, checking all 12 keys are present). Fix and re-validate if anything fails — don't show the user a line that hasn't passed this check.
- As part of that same validation pass, extract `code` and `fixed_code` for every row into real files in the stated language and confirm each one is complete: it has its includes/imports, it has an entry point, and — whenever a compiler/interpreter for that language is available in the sandbox — it actually compiles or parses cleanly. A row whose code doesn't pass this isn't done; finish the program and re-validate rather than shipping it with a caveat.
- Present the final JSONL inside a single fenced code block in the chat reply so it can be copy-pasted straight into a `.jsonl` file. Don't create a downloadable file unless the user asks for one.
- One output line per input prompt, in the same order the prompts were given.

## Reference example (target shape)

```json
{"id": 1, "is_vulnerable": true, "vulnerability_type": "Stack Buffer Overflow", "cwe_id": "CWE-121", "owasp_category": "A04:2021-Insecure Design", "severity": "Critical", "cvss_score": 9.8, "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", "code": "...complete vulnerable C++ program...", "fixed_code": "...complete corrected C++ program...", "root_cause": "...which function/line and why...", "explanation": "...CWE/OWASP rationale, conceptual exploitation, impact, how the fix mitigates it..."}
```
